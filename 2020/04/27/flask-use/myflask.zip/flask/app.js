//app.js
App({
    globalData: {
        appid: 'wxdaf43d31091de716', //appid需自己提供，此处的appid我随机编写
        secret: 'ff5b0b7848777516e4fc3434b8652349', //secret需自己提供，此处的secret我随机编写

    },

    onLaunch: function() {
        // 展示本地存储能力
        var logs = wx.getStorageSync('logs') || []
        logs.unshift(Date.now())
        wx.setStorageSync('logs', logs)
        var that = this
        var user = wx.getStorageSync('user') || {};
        var userInfo = wx.getStorageSync('userInfo') || {};
        if ((!user.openid || (user.expires_in || Date.now()) < (Date.now() + 600)) && (!userInfo.nickName)) {
            wx.login({
                success: function(res) {
                    if (res.code) {
                        wx.getUserInfo({
                            success: function(res) {
                                var objz = {};
                                objz.avatarUrl = res.userInfo.avatarUrl;
                                objz.nickName = res.userInfo.nickName;
                                //console.log(objz);
                                wx.setStorageSync('userInfo', objz); //存储userInfo
                            }
                        });
                        var appid = 'wxdaf43d31091de716'; //appid需自己提供，此处的appid我随机编写
                            var secret = 'ff5b0b7848777516e4fc3434b8652349';//secret需自己提供，此处的secret我随机编写
                                //var d = that.globalData; //这里存储了appid、secret、token串  
                                var l = 'https://api.weixin.qq.com/sns/jscode2session?appid=' + appid + '&secret=' + secret + '&grant_type=authorization_code&js_code=' + res.code;
                        wx.request({
                            url: l,
                            data: {},

                            method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT  
                            header: {}, // 设置请求的 header  
                            success: function(res) {
                              console.log(res.data.openid)
                                var obj = {};
                                obj.openid = res.data.openid;
                                obj.expires_in = Date.now() + res.data.expires_in;
                                //console.log(obj);
                                wx.setStorageSync('user', obj); //存储openid  
                            }
                        });
                       
                    } else {
                        console.log('获取用户登录态失败！' + res.errMsg)
                    }
                }
            });
        }
        // 登录

        // 获取用户信息
        wx.getSetting({
            success: res => {
                if (res.authSetting['scope.userInfo']) {
                    // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
                    wx.getUserInfo({
                        success: res => {
                            // 可以将 res 发送给后台解码出 unionId
                            this.globalData.userInfo = res.userInfo

                            // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
                            // 所以此处加入 callback 以防止这种情况
                            if (this.userInfoReadyCallback) {
                                this.userInfoReadyCallback(res)
                            }
                        }
                    })
                }
            }
        })
      var user = wx.getStorageSync('user')
      var userInfo = wx.getStorageSync('userInfo')
      wx.request({
        url: 'http://192.168.0.103:8090/adduserordinary/' + user.Object.openid + '/'+userInfo.Object.nickName + '/',
        success: function (res) { }
      })
    },

    globalData: {
        userInfo: null
    }
})