
const $vm = getApp()

const cache = Object.create(null)

//const { decodeHtml, parseNews } = $vm.utils

Page({
    data: {
        scrollHeight: 0, //页面高度
        currentID: 7, //新闻类型
        TianAPInewsList: [], //默认数据列表
        scrollTop: 0, //Y轴滚动条位置
        touchXStart: 0, //X轴开始位置
        touchYStart: 0, //Y轴开始位置
        currentPage: 1, //默认页数
    },
    onLoad: function() {
      //this.adduser();
        this.loadNewslList(7);
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    adduser: function(e){
      
      wx.request({
        url: 'http://192.168.0.103:8090/adduserordinary/' + e.detail.value.openid + '/' + e.detail.value.nickname + '/',
        success: function (res) { }
      })
    },
    initNewsData: function() { //初始化数据
        this.setData({
            scrollTop: 0,
            TianAPInewsList: [],
            currentPage: 1,
            scrollHeight: 0
        });
    },
    refreshNewList: function(e) { //获取最新数据
        this.initNewsData();
        this.loadNewslList(this.data.currentID);
    },
    loadMoreNews: function(e) { //加载更多新闻数据
        this.setData({ currentPage: this.data.currentPage + 1 });
        this.loadNewslList(this.data.currentID);
    },
    setCurrentYScroll: function(event) { //设置当前Y轴滚动条位置
        this.setData({
            scrollTop: event.detail.scrollTop
        });
    },
    loadNewslList: function(NewsTypeId = "") { //加载新闻列表
      var that = this;
      wx.getStorage({
        key: 'user',
        success: function (res) {
          that.setData({ open: res.data.openid })
        },
      })
      wx.getStorage({
        key: 'userInfo',
        success: function (res) {
          that.setData({ nick: res.data.nickName })
        },
      })
        wx.showLoading({ title: '加载中...' })
        wx.request({
            url: 'http://192.168.0.103:8090/getarticle/',
            success: function(res) {

                console.log(res)
                let temp_data = res.data.newslist;
                that.setData({ TianAPInewsList: temp_data });

                wx.getSystemInfo({ //设置scroll内容高度
                    success: function(res) {
                        that.setData({
                            scrollHeight: res.windowHeight,
                        });
                    }
                });
                wx.hideLoading() //关闭加载提示
            }
        })
    },

    handerNavigator: function(e) { //点击新闻列表跳转
        var id = e.currentTarget.dataset.id // 新闻url 
        wx.navigateTo({
            url: '/pages/view/view?id=' + id
        });
    }
});