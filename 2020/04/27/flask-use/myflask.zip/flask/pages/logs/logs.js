var util = require('../../utils/util.js')
Page({
  data: {},
  onLoad: function (options) {
    this.loadNewsContent(options.article_id);
    this.loadcommentContent(options.article_id);
    wx.showShareMenu({
      withShareTicket: true
    })
  },
  loadcommentContent: function (id) { //加载评论内容
    let that = this;

    wx.showLoading({ title: '加载中...' })

    wx.request({
      url: 'http://192.168.0.103:8090/getcomment/' + id + '/',

      success: function (res) {
        console.log(res)
        let temp_data = res.data.comment;

        that.setData({
          TianAPIcommentsList: temp_data
        });



        wx.hideLoading() //关闭加载提示
      }
    })
  },
  loadNewsContent: function (id) { //加载新闻内容
    let that = this;

    wx.showLoading({ title: '加载中...' })

    wx.request({
      url: 'http://192.168.0.103:8090/getdetail/' + id + '/',

      success: function (res) {
        console.log(res)
        let temp_data = res.data
        
        that.setData({
          TianAPInewsTitle1: temp_data.title,
          TianAPInewsContent1: temp_data.content,
          TianAPInewsContentTime1: temp_data.ctime,
          TianAPInewspic1: temp_data.picUrl,
          TianAPInewsid1: temp_data.id
        });
        wx.getStorage({
          key: 'user',
          success: function (res) {
            that.setData({ TianAPInewsopenid1: res.data.openid })
          },
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({ TianAPInewsnickname1: res.data.nickName })
          },
        })

      }
    })
  },
  addcollection: function (e) {
    wx.request({
      url: 'http://192.168.0.103:8090/cancelcollection/' + e.detail.value.id + '/' + e.detail.value.openid + '/',
      success: function (res) {
        wx.navigateTo({
          url: '/pages/fav/fav'
        });
      }
    })
  },
  formSubmit: function (e) {
    let that = this;
    var user = wx.getStorageSync('user');
    var open;


    wx.request({
      url: 'http://192.168.0.103:8090/add_comment/' + e.detail.value.id + '/' + e.detail.value.openid + '/' + e.detail.value.comment_content + '/',

      success: function (res) {
        this.loadcommentContent(res.data.id);
        wx.showShareMenu({
          withShareTicket: true
        })




      }
    })
  }
});